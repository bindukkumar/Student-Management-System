package com.capg.student;

public class Student {
	
	int rollno;
	String name;
	String branch;
	int sem;
	String gender;
	double cgpa;
	
	public Student(int rollno, String name, String branch, int sem, String gender, double cgpa) {
		this.rollno = rollno;
		this.name = name;
		this.branch = branch;
		this.sem = sem;
		this.gender = gender;
		this.cgpa = cgpa;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public int getSem() {
		return sem;
	}

	public void setSem(int sem) {
		this.sem = sem;
	}

	public double getCgpa() {
		return cgpa;
	}

	public void setCgpa(double cgpa) {
		this.cgpa = cgpa;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", name=" + name + ", gender=" + gender + ", branch=" + branch + ", sem="
				+ sem + ", cgpa=" + cgpa + "]";
	}
	
	
	

}
