package com.capg.student;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class StudentList {
	public static void main(String[] args) {
		List<Student> stuList = new ArrayList<Student>();
		stuList.add(new Student(1,"Arun","ISE",3,"Male",6.9));
		stuList.add(new Student(2,"Aksh","CSE",3,"Male",7.9));
		stuList.add(new Student(3,"Arpitha","ECE",3,"Female",6.5));
		stuList.add(new Student(4,"Asmitha","EEE",3,"Female",7.5));
		stuList.add(new Student(5,"Bindu","ISE",4,"Female",8.0));
		stuList.add(new Student(6,"Dhruva","CSE",4,"Male",8.9));
		stuList.add(new Student(7,"Hema","ECE",4,"Female",9.0));
		stuList.add(new Student(8,"Gnana","ISE",5,"Female",7.4));
		stuList.add(new Student(9,"Gagana","ISE",5,"Female",7.6));
		stuList.add(new Student(10,"Kavana","ECE",5,"Female",6.8));
		stuList.add(new Student(11,"Kiran","EEE",5,"Male",7.5));
		stuList.add(new Student(12,"Nidhi","CSE",6,"Female",8.2));
		stuList.add(new Student(13,"Sasmitha","ECE",6,"Female",8.3));
		stuList.add(new Student(14,"sindhu","EEE",6,"Female",9.2));
		stuList.add(new Student(15,"Rakesh","CSE",7,"Male",8.6));



		//Number of male and female students in college

		Map<String, Long> noOfMaleAndFemaleStudent=
				stuList.stream().collect(Collectors.groupingBy(Student::getGender, Collectors.counting()));

		System.out.println("Number of male and Female Students:"+ noOfMaleAndFemaleStudent);//Female=10, Male=5
		System.out.println("------------------------------------------------------");		
		//Name of the Students in Organization		

		String name=stuList.stream()
				.map(Student::getName)
				.collect(Collectors.joining(","));
		System.out.println("Name of the Students: "+name);
		System.out.println("------------------------------------------------------");	

		//Details of the Student who has scored highest cgpa

		Optional<Student> highestScoredStudents=
				stuList.stream().collect(Collectors.maxBy(Comparator.comparingDouble(Student::getCgpa)));
		Student highestScoredStudent =highestScoredStudents.get();

		System.out.println("Details of the Student who has Scored highest cgpa:");
		System.out.println("----------------------");	
		System.out.println("Roll Number: "+highestScoredStudent.getRollno());
		System.out.println("Name: "+highestScoredStudent.getName());
		System.out.println("Branch: "+highestScoredStudent.getBranch());
		System.out.println("Gender: "+highestScoredStudent.getGender());
		System.out.println("Sem: "+highestScoredStudent.getSem());
		System.out.println("CGPA: "+highestScoredStudent.getCgpa());

		System.out.println("------------------------------------------------------");

		// Name of Female and Male Students

		Map<String, List<Student>> studentListByGender=
				stuList.stream().collect(Collectors.groupingBy(Student::getGender));
		Set<Entry<String, List<Student>>> entrySet = studentListByGender.entrySet();
		System.out.println("Name of Female and Male Students");
		for (Entry<String, List<Student>> entry : entrySet) 
		{
			System.out.println("-------------------");
			System.out.println(entry.getKey() + " Students : ");        
			System.out.println("-------------------");

			List<Student> list = entry.getValue();        
			for (Student e : list) 
			{
				System.out.println(e.getName());
			}
		}

		System.out.println("------------------------------------------------------");

		//Number of students in each department
		System.out.println("Number of students in each department");
		System.out.println("-------------------");
		Map<String, Long> noOfStudentsByBranch=
				stuList.stream().collect(Collectors.groupingBy(Student::getBranch, Collectors.counting()));        
		Set<Entry<String, Long>> entSet = noOfStudentsByBranch.entrySet();        
		for (Entry<String, Long> ent : entSet)
		{
			System.out.println(ent.getKey()+" : "+ent.getValue());
		}
		System.out.println("------------------------------------------------------");

		//Name of the Students according to Branch
		System.out.println("Name of the Students according to Branch");
		Map<String, List<Student>> studentNameByDepartment=
				stuList.stream().collect(Collectors.groupingBy(Student::getBranch));

		Set<Entry<String, List<Student>>> enSet = studentNameByDepartment.entrySet();

		for (Entry<String, List<Student>> en : enSet) 
		{
			System.out.println("--------------------------------------");

			System.out.println("Students In "+en.getKey() + " : ");

			System.out.println("--------------------------------------");

			List<Student> list = en.getValue();

			for (Student e : list) 
			{
				System.out.println(e.getName());
			}
		}		
		System.out.println("------------------------------------------------------");	
		// Avg cgpa of each Branch
		System.out.println("Average CGPA of each Branch");
		System.out.println("---------------------------");
		Map<String, Double> avgCGPAOfBranch=
				stuList.stream().collect(Collectors.groupingBy(Student::getBranch, Collectors.averagingDouble(Student::getCgpa)));

		Set<Entry<String, Double>> eSet = avgCGPAOfBranch.entrySet();

		for (Entry<String, Double> entry : eSet) 
		{
			System.out.println(entry.getKey()+" : "+entry.getValue());
		}
		System.out.println("------------------------------------------------------");
		//Avg CGPA according to gender

		System.out.println("Average CGPA of Male and Female Students");
		System.out.println("---------------------------");
		Map<String, Double> avgCGPAOfGender=
				stuList.stream().collect(Collectors.groupingBy(Student::getGender, Collectors.averagingDouble(Student::getCgpa)));

		Set<Entry<String, Double>> entrySet1 = avgCGPAOfGender.entrySet();

		for (Entry<String, Double> entry : entrySet1) 
		{
			System.out.println(entry.getKey()+" : "+entry.getValue());

		}
		System.out.println("------------------------------------------------------");
		// Number of Female and Male Students in ISE Branch		
		System.out.println("Number of Female and Male Students in ISE Branch");
		System.out.println("-----------------------------");
		Map<String, Long> noMaleFemaleStudentsInIse=
				stuList.stream()
				.filter(e -> e.getBranch()=="ISE")
				.collect(Collectors.groupingBy(Student::getGender, Collectors.counting()));

		System.out.println(noMaleFemaleStudentsInIse);
		System.out.println("---------------------------------------------------");
		//Students Name Who has score more than 8 Cgpa and less than 8 CGPA
		System.out.println("Students Name Who has score more than 8 Cgpa and less than 8 CGPA ");
		Map<Boolean, List<Student>> StudentName=
				stuList.stream().collect(Collectors.partitioningBy(stu->stu.getCgpa() > 8.0 ));

		Set<Entry<Boolean, List<Student>>> entrySet2 = StudentName.entrySet();

		for (Entry<Boolean, List<Student>> entry : entrySet2) 
		{
			System.out.println("----------------------------");

			if (entry.getKey()) 
			{
				System.out.println("Students who has scored more than 8 CGPA :");
			}
			else
			{
				System.out.println("Students who has scored less than 8 CGPA :");
			}

			System.out.println("----------------------------");

			List<Student> list = entry.getValue();

			for (Student s : list) 
			{
				System.out.println(s.getName());
			}
		}
		System.out.println("---------------------------------------------------");
		//Name of the Branches
		System.out.println("Name of the Branches");
		System.out.println("-----------------");
		stuList.stream()
        .map(Student::getBranch)
        .distinct()
        .forEach(System.out::println);
		System.out.println("---------------------------------------------------");
		//Min scorer
		Optional<Student> lessScoredStudents=
				stuList.stream().collect(Collectors.minBy(Comparator.comparingDouble(Student::getCgpa)));
		Student lessScoredStudent =lessScoredStudents.get();

		System.out.println("Details of the Student who has Scored less cgpa:");
		System.out.println("----------------------");	
		System.out.println("Roll Number: "+lessScoredStudent.getRollno());
		System.out.println("Name: "+lessScoredStudent.getName());
		System.out.println("Branch: "+lessScoredStudent.getBranch());
		System.out.println("Gender: "+lessScoredStudent.getGender());
		System.out.println("Sem: "+lessScoredStudent.getSem());
		System.out.println("CGPA: "+lessScoredStudent.getCgpa());

		System.out.println("------------------------------------------------------");
		//Student name who has score more than 9 CGPA
		System.out.print("Student name who has score more than 9 CGPA:");
		stuList.stream()
        .filter(e -> e.getCgpa() > 9)
        .map(Student::getName)
        .forEach(System.out::println);
		System.out.println("------------------------------------------------------");
		
		//Name of Females in ISE Branch
		System.out.println("Name of Females in ISE Branch");
		System.out.println("------------");
		stuList.stream()
        .filter(e -> e.getGender()=="Female" && e.getBranch()=="ISE")
        .map(Student::getName)
        .forEach(System.out::println);
		
		System.out.println("------------------------------------------------------");
		//Name of Males in CSE Branch
		System.out.println("Name of Males in CSE Branch");
		System.out.println("------------");
		stuList.stream()
        .filter(e -> e.getGender()=="Male" && e.getBranch()=="CSE")
        .map(Student::getName)
        .forEach(System.out::println);
		System.out.println("------------------------------------------------------");
		
		//Details of the student who has scored more cgpa in ECE branch
		
		Optional<Student> highestScorerinECE=
				stuList.stream()
				            .filter(stu->stu.getBranch()=="ECE")
				            .max(Comparator.comparingDouble(Student::getCgpa));
				         
				Student highestScorerinECEIs = highestScorerinECE.get();
				         
				System.out.println("Details of the student who has scored more cgpa in ECE branch");
				         
				System.out.println("----------------------------------------------");
				         
				System.out.println("Roll Num : "+highestScorerinECEIs.getRollno());        
				System.out.println("Name : "+highestScorerinECEIs.getName());
				System.out.println("CGPA : "+highestScorerinECEIs.getCgpa());     
				System.out.println("Gender : "+highestScorerinECEIs.getGender());
				System.out.println("Sem  :"+highestScorerinECEIs.getSem());
       
		System.out.println("------------------------------------------------------");
		
		//Details of male students who has cgpa more than 7
		System.out.println("Details of male students who has cgpa more than 7");
		System.out.println("------------");
		stuList.stream()
        .filter(e -> e.getGender()=="Male" && e.getCgpa() > 7.0)
        .map(Student::getName)
        .forEach(System.out::println);
		System.out.println("------------------------------------------------------");

		//Details of female students who has cgpa more than 8
				System.out.println("Details of male students who has cgpa more than 8");
				System.out.println("------------");
				stuList.stream()
		        .filter(e -> e.getGender()=="Female" && e.getCgpa() > 8.0)
		        .map(Student::getName)
		        .forEach(System.out::println);
				System.out.println("------------------------------------------------------");



	}








}
